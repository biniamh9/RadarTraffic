import os
import numpy as np
import pandas as pnda
from matplotlib import pyplot as pyplt
import report_generator as  reportgen

###################################################################################################################################
#
#
# #################################################################################################################################
def generte_per_sensor_plot(df, intersection, date_col, attr_col, lane_col, attr, plot_file_name):
    pyplt.scatter(np.arange(len(date_col)), attr_col, color='r')
    axes = pyplt.gca()
    #axes.xaxis.set_ticks(np.arange(len(df['Read Date'])))
    axes.xaxis.set_ticks(np.arange(len(df['Read Date'])))
    axes.xaxis.set_ticklabels(date_col+' '+ lane_col, rotation=90, size='medium')
    pyplt.xlabel("Data Read Date")
    pyplt.ylabel(intersection)
    title = str(intersection) + " -  "  + attr
    pyplt.title(title)
    pyplt.legend(loc='YYYY')
    pyplt.grid(True, color='0.9')
    pyplt.savefig(plot_file_name, dpi=None, facecolor='w', edgecolor='w', orientation='portrait', papertype=None,format=None, transparent=False, bbox_inches=None, pad_inches=0.1, frameon=None, metadata=None)
    #pyplt.show()
    pyplt.cla()
    pyplt.clf()
    pyplt.close()
###################################################################################################################################
#
#
# #################################################################################################################################
def generate_avg_attr_values(df, attr_col):
    attr_val_sum = 0
    attr_vals_cnt = 0
    attr_avg = 0
    for val in attr_col:
        attr_vals_cnt+=1
        attr_val_sum+=val
    attr_avg = attr_val_sum // attr_vals_cnt
    print('attr_val_sum: ', attr_val_sum)
    print('attr_vals_cnt', attr_vals_cnt)
    print('attr_avg: ', attr_avg)
    print("-------------")
    return attr_avg


###################################################################################################################################
#
#
# #################################################################################################################################
def process_data(df, intersection):
    plots_dir = r'..\Project_Plots'
    #Process Volume
    attributes = ['Volume', 'Occupancy', 'Speed']
    avg_values = []
    attrs_dic = {}
    for attr in attributes:
        intersection_dir = os.path.join(plots_dir, intersection)
        if not os.path.exists(intersection_dir):
            os.makedirs(intersection_dir)
        plot_file_name = os.path.join(intersection_dir,attr+'.png')
        date_col = df['Read Date']
        attr_col = df[attr]
        lane_name = df['Lane']
        generte_per_sensor_plot(df, intersection, date_col, attr_col, lane_name, attr, plot_file_name)
        print('Processing :', attr)
        avg_val = generate_avg_attr_values(df, attr_col)
        avg_values.append(avg_val)
    attrs_dic[intersection] = avg_values
    print(attrs_dic)
    maint_flag, maint_sched = reportgen.determine_road_maint(attrs_dic, intersection)
    reportgen.generatereport(intersection, avg_values, intersection_dir, maint_flag, maint_sched)



