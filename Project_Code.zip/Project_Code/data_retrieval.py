import numpy as np
import pandas as pnda
from matplotlib import pyplot as pyplt
import os
import sys
#import cv2
#############################################################################################################
# #
# #
# #
#############################################################################################################
def import_data():
    analysisCsv = r'..\Project_Data\austintexas_traffic_gov.csv'
    df = pnda.read_csv(analysisCsv)
    return df
#############################################################################################################
# #
# #
# #
#############################################################################################################
def retrieve_data(intersection, start_date, end_date):
    print("retrieve_data: ", intersection, start_date, end_date)
    df = import_data()
    print('*' * 40)
    #print(df.to_string())
    print('*' * 40)
    #print(df['Detector ID'].to_string())
    intersection_df = df[df['Intersection Name'] == intersection]
    print(intersection_df.to_string())
    #sensor_data = df[df['Detector ID'] == senser_id]
    print("HOLD..................HERE.............")
    return intersection_df