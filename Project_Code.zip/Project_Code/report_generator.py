import os
###################################################################################################################################
#
#
# #################################################################################################################################
def calculate_road_maint_schded(vol_diff,occ_diff,speed_diff):
    rec_maint_date = 0
    if vol_diff > 500 :
        if occ_diff > 50 and speed_diff > 10:
            rec_maint_date = 90
        else:
            rec_maint_date = 120
    elif vol_diff > 50:
        if occ_diff > 50 and speed_diff > 10:
            rec_maint_date = 160
        else:
            rec_maint_date = 180
    elif vol_diff > 10:
        if occ_diff > 50 and speed_diff > 10:
            rec_maint_date = 200
        else:
            rec_maint_date = 220
    elif vol_diff > 2:
        if occ_diff > 50 and speed_diff > 10:
            rec_maint_date = 240
        else:
            rec_maint_date = 260
    return rec_maint_date
###################################################################################################################################
#
#
# #################################################################################################################################
def determine_road_maint(attrs_dic, intersection):
    vals_cnt = 0
    rec_maint_date = 0
    maint_flag = False
    vol_maint_threshold = 100
    occup_maint_threshold = 10
    speed_maint_threshold = 20

    vals = attrs_dic[intersection]
    for val in vals:
        if vals_cnt == 0:
            vol = val
        if vals_cnt == 1:
            occ = val
        if vals_cnt == 2:
            speed = val
        vals_cnt += 1
    vol_diff = vol - vol_maint_threshold
    occ_diff = occ - occup_maint_threshold
    speed_diff = speed - speed_maint_threshold
    #Set maint flag
    if vol_diff != 0 and occ_diff != 0 and speed_diff != 0:
        maint_flag = True
        #Calculate road maint schedu
        rec_maint_date = calculate_road_maint_schded(vol_diff,occ_diff,speed_diff)
    return maint_flag, rec_maint_date
###################################################################################################################################
#
#
# #################################################################################################################################
def generatereport(intersection, avg_values, intersection_dir, maint_flag, maint_sched):
    report_dir = r'..\TrafficFlowAndMaintReport'
    report_file = os.path.join(report_dir,intersection+'_report.html')
    img_src = r'‪..\Project_Plots\Robert E LeeBarton Springs\Volume.png'
    if maint_flag == True:
        main_str = "True"
    else:
        main_str = "False"
    str1 = 'Traffic Flow & Road Maintanance Recommendation Report'
    str2 = 'Intersection Name: ' + intersection
    if maint_sched == 0:
        str3 = 'Road Maint is required in: ' + 'Routine Maintenance is only requred'
    else:
        str3 = 'Road Maint is required in: ' + str(maint_sched) + ' ' + 'days'
    str4 = '_______________________________________________________________'
    fptr = open(report_file, "w")
    html_str = """
    <header>
    <h1>%s</h1>
    </header>
    <body>    
    <h3>%s</h3>
    <h3>%s</h3>
    <h3>%s</h3>
    <h3>%s</h3>
    <h3>Traffic Volume Summary</h3>
    <h3>Average Volume : %s Vehicles Per 15 min Interval</h3>
    <h3> Volume Graph:  </h3>
    <img src="..\\Project_Plots\\%s\\Volume.png" width="700" height="500"/>
    <h3>%s</h3>
    <h3>Traffic Occupancy Summary </h3>
    <h3>Average Occupancy : %s Vehicles Per 15 min Interval</h3>
    <h3> Occupacy Graph:  </h3>
    <img src="..\\Project_Plots\\%s\\Occupancy.png" width="700" height="500"/>
    <h3>%s</h3>
    <h3>Traffic Speed Summary</h3>
    <h3>Average Speed : %s M/S Within 15 min Interval</h3>
    <h3> Speed Graph:  </h3>
    <img src="..\\Project_Plots\\%s\\Speed.png" width="700" height="500"/>    
   </body>
    """%(str1, str2, str4, str3, str4, avg_values[0], intersection,str4, avg_values[1], intersection,str4, avg_values[2], intersection)
    fptr.write(html_str)
    fptr.close()