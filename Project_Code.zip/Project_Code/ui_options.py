import warnings
#import cv2
import data_retrieval as dataretv
import data_processing as dataproc
import time
warnings.filterwarnings('ignore')

def verfiy_input(intesec_selection_list):
    ver_status = 0
    if intesec_selection_list == '':
        ver_status = 0
    else:
        for ch in intesec_selection_list:
            if ch == ' ':
                continue
            if ch in ['1','2','3','4','5','6']:
                ver_status = 1
            else:
                ver_status = 0
                break
    return ver_status
###################################################################################################################################
#
#
# #################################################################################################################################
def get_main_option(dict_opt):
    #print(dict_opt)
    print("="*100)
    for(k, v) in dict_opt.items():
        print("%9s -- %d" % (k,v))
    print("=" * 100)

    while True:
        intesec_selection_list = input("Select Intersection/s Number Listed Above For Traffic Flow and Road Maintenance Analysis Separted by Space: ")
        ver_status = verfiy_input(intesec_selection_list)
        if ver_status == 0:
            print('Invalide Input: Input should be one or more Intersection/s Number Listed Above')
        else:
            input_list = intesec_selection_list.split()
            break
    return input_list
###################################################################################################################################
#
#
# #################################################################################################################################
def get_sub_option(stat_type):
    if stat_type == 1:#volume:
        date = str(input("Enter Volume Stat date <MM/DD/YYYY>: "))
        senser_id = str(input("Enter Sensor: "))
        traffic_direction = str(input("Enter Traffic Direction: "))
    if stat_type == 2:# speed
        pass
    if stat_type == 3:#OCCUPANCY
        pass
    return date,senser_id,traffic_direction
###################################################################################################################################
#
#
# #################################################################################################################################
def ui_options():
    intersections_list = ['Robert E LeeBarton Springs', 'N Lamar15th', 'BURNETPALM WAY', 'BurnetRutland','LOOP 360CEDAR', 'LAMARSANDRA MURAIDA']
    dict_opt = {}
    intersec_indx = 0
    for intersc in intersections_list:
        intersec_indx += 1
        dict_opt[intersc] = intersec_indx
    intersection_select = get_main_option(dict_opt)
    for (k, v) in dict_opt.items():
        if str(v) not in intersection_select:
            continue
        else:
            start_date = '5/13/2019-18:00'
            end_date = '5/13/2019-18:30'
            start_analysis(k, start_date, end_date)
###################################################################################################################################
#
#
# #################################################################################################################################
def start_analysis(intersection, start_date, end_date):
    df = dataretv.retrieve_data(intersection, start_date, end_date)
    dataproc.process_data(df, intersection)
###################################################################################################################################
#
#
# #######################################################################  ##########################################################
def main():
    ui_options()
###################################################################################################################################
#
#
# #################################################################################################################################
if __name__ == "__main__":
    main()
